from .syslog_rust import *

__doc__ = syslog_rust.__doc__
if hasattr(syslog_rust, "__all__"):
    __all__ = syslog_rust.__all__