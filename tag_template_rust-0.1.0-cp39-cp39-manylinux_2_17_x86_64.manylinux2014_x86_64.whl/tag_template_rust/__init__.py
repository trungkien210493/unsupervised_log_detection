from .tag_template_rust import *

__doc__ = tag_template_rust.__doc__
if hasattr(tag_template_rust, "__all__"):
    __all__ = tag_template_rust.__all__